===============================================================================
=    W i t a j   w   t u t o r i a l u   V I M - a      -    Wersja  1.7.     =
===============================================================================

     Vim to pot�ny edytor, kt�ry posiada wiele polece�, zbyt du�o, by
     wyja�ni� je wszystkie w tym tutorialu. Ten przewodnik ma nauczy�
     Ci� pos�ugiwa� si� wystarczaj�co wieloma komendami, by� m�g� �atwo
     u�ywa� Vima jako edytora og�lnego przeznaczenia.

     Czas potrzebny na uko�czenie tutoriala to 25 do 30 minut i zale�y
     od tego jak wiele czasu sp�dzisz na eksperymentowaniu.

	 UWAGA:
	 Polecenia wykonywane w czasie lekcji zmodyfikuj� tekst. Zr�b
	 wcze�niej kopi� tego pliku do �wicze� (je�li zacz��e� komend�
	 "vimtutor", to ju� pracujesz na kopii).

	 Pami�taj, �e przewodnik ten zosta� zaprojektowany do nauki poprzez
	 �wiczenia. Oznacza to, �e musisz wykonywa� polecenia, by nauczy� si� ich
	 prawid�owo. Je�li b�dziesz jedynie czyta� tekst, szybko zapomnisz wiele
	 polece�!

     Teraz upewnij si�, �e nie masz wci�ni�tego Caps Locka i wciskaj  j
     tak d�ugo dop�ki Lekcja 1.1. nie wype�ni ca�kowicie ekranu.

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		  Lekcja 1.1.: PORUSZANIE SI� KURSOREM

       ** By wykona� ruch kursorem, wci�nij h, j, k, l jak pokazano. **

	       ^
	       k		      Wskaz�wka:  h jest po lewej
	  < h	  l >				  l jest po prawej
	       j				  j wygl�da jak strza�ka w d�
	       v
  1. Poruszaj kursorem dop�ki nie b�dziesz pewien, �e pami�tasz polecenia.

  2. Trzymaj  j  tak d�ugo a� b�dzie si� powtarza�.
     Teraz wiesz jak doj�� do nast�pnej lekcji.

  3. U�ywaj�c strza�ki w d� przejd� do nast�pnej lekcji.

Uwaga: Je�li nie jeste� pewien czego� co wpisa�e�, wci�nij <ESC>, by wr�ci� do
       trybu Normal. Wtedy powt�rz polecenie.

Uwaga: Klawisze kursora tak�e powinny dzia�a�, ale u�ywaj�c  hjkl  b�dziesz
       w stanie porusza� si� o wiele szybciej, jak si� tylko przyzwyczaisz.
       Naprawd�!

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		    Lekcja 1.2.: WYCHODZENIE Z VIM-a

 !! UWAGA: Przed wykonaniem jakiegokolwiek polecenia przeczytaj ca�� lekcj� !!

  1. Wci�nij <ESC> (aby upewni� si�, �e jeste� w trybie Normal).
  2. Wpisz:			:q!<ENTER>.
     To spowoduje wyj�cie z edytora PORZUCAJ�C wszelkie zmiany, jakie
     zd��y�e� zrobi�. Je�li chcesz zapami�ta� zmiany i wyj��,
     wpisz:			:wq<ENTER>

  3. Kiedy widzisz znak zach�ty pow�oki wpisz komend�, �eby wr�ci�
     do tutoriala. Czyli:	vimtutor<ENTER>

  4. Je�li chcesz zapami�ta� polecenia, wykonaj kroki 1. do 3., aby
     wyj�� i wr�ci� do edytora.

UWAGA: :q!<ENTER> porzuca wszelkie zmiany jakie zrobi�e�. W nast�pnych
       lekcjach dowiesz si� jak je zapami�tywa�.

  5. Przenie� kursor do lekcji 1.3.


~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		 Lekcja 1.3.: EDYCJA TEKSTU - KASOWANIE

	    ** Wci�nij  x  aby usun�� znak pod kursorem. **

  1. Przenie� kursor do linii poni�ej oznaczonej --->.

  2. By poprawi� b��dy, naprowad� kursor na znak do usuni�cia.

  3. Wci�nij  x  aby usun�� niechciany znak.

  4. Powtarzaj kroki 2. do 4. dop�ki zdanie nie jest poprawne.

---> Kkrowa prrzeskoczy�a prrzez ksii�ycc.

  5. Teraz, kiedy zdanie jest poprawione, przejd� do Lekcji 1.4.

UWAGA: Ucz si� przez �wiczenie, nie wkuwanie.





~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	   Lekcja 1.4.: EDYCJA TEKSTU - INSERT (wprowadzanie)


		  ** Wci�nij  i  aby wstawi� tekst. **

  1. Przenie� kursor do pierwszej linii poni�ej oznaczonej --->.

  2. Aby poprawi� pierwszy wiersz, ustaw kursor na pierwszym znaku PO tym,
     gdzie tekst ma by� wstawiony.

  3. Wci�nij  i  a nast�pnie wpisz konieczne poprawki.

  4. Po poprawieniu b��du wci�nij <ESC>, by wr�ci� do trybu Normal.
     Powtarzaj kroki 2. do 4., aby poprawi� ca�e zdanie.

---> W tej brkje troch� .
---> W tej linii brakuje troch� tekstu.

  5. Kiedy czujesz si� swobodnie wstawiaj�c tekst, przejd� do
     podsumowania poni�ej.


~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	   Lekcja 1.5.: EDYCJA TEKSTU - APPENDING (dodawanie)


		   ** Wci�nij  A  by doda� tekst. **

  1. Przenie� kursor do pierwszej linii poni�ej oznaczonej --->.
     Nie ma znaczenia, kt�ry to b�dzie znak.

  2. Wci�nij  A  i wpisz odpowiednie dodatki.

  3. Kiedy tekst zosta� dodany, wci�nij <ESC> i wr�� do trybu Normalnego.

  4. Przenie� kursor do drugiej linii oznaczonej ---> i powt�rz kroki 2. i 3.,
     aby poprawi� zdanie.

---> Brakuje tu tro
     Brakuje tu troch� tekstu.
---> Tu te� troch� bra
     Tu te� troch� brakuje.

  5. Kiedy ju� utrwali�e� �wiczenie, przejd� do lekcji 1.6.

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
			  Lekcja 1.6.: EDYCJA PLIKU

		  ** U�yj  :wq  aby zapisa� plik i wyj��. **

   !! UWAGA: zanim wykonasz jakiekolwiek polecenia przeczytaj ca�� lekcj� !!

  1. Zako�cz tutorial tak jak w lekcji 1.2.:  :q!
     lub, je�li masz dost�p do innego terminala, wykonaj kolejne kroki tam.

  2. W pow�oce wydaj polecenie:  vim tutor<ENTER>
     "vim" jest poleceniem uruchamiaj�cym edytor Vim. 'tutor' to nazwa pliku,
     jaki chcesz edytowa�. U�yj pliku, kt�ry mo�e zosta� zmieniony.

  3. Dodaj i usu� tekst tak, jak si� nauczy�e� w poprzednich lekcjach.

  4. Zapisz plik ze zmianami i opu�� Vima:  :wq<ENTER>

  5. Je�li zako�czy�e� vimtutor w kroku 1., uruchom go ponownie i przejd�
     do podsumowania poni�ej.

  6. Po przeczytaniu wszystkich krok�w i ich zrozumieniu: wykonaj je.

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
			     LEKCJA 1. PODSUMOWANIE

  1. Poruszasz kursorem u�ywaj�c "strza�ek" i klawiszy  hjkl .
       h (w lewo)	 j (w d�)	 k (do g�ry)		l (w prawo)

  2. By wej�� do Vima, (z pow�oki) wpisz:
			    vim NAZWA_PLIKU<ENTER>

  3. By wyj�� z Vima, wpisz:
			    <ESC> :q!<ENTER>  by usun�� wszystkie zmiany.
	     LUB:	    <ESC> :wq<ENTER>  by zmiany zachowa�.

  4. By usun�� znak pod kursorem, wci�nij:  x

  5. By wstawi� tekst przed kursorem lub doda�:
	i   wpisz tekst   <ESC>         wstawi przed kursorem
	A   wpisz tekst   <ESC>         doda na ko�cu linii

UWAGA: Wci�ni�cie <ESC> przeniesie Ci� z powrotem do trybu Normal
       lub odwo�a niechciane lub cz�ciowo wprowadzone polecenia.

Teraz mo�emy kontynuowa� i przej�� do Lekcji 2.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		  Lekcja 2.1.: POLECENIE DELETE (usuwanie)


		      ** Wpisz  dw  by usun�� wyraz. **

  1. Wci�nij  <ESC>, by upewni� si�, �e jeste� w trybie Normal.

  2. Przenie� kursor do linii poni�ej oznaczonej --->.

  3. Przesu� kursor na pocz�tek wyrazu, kt�ry chcesz usun��.

  4. Wpisz   dw   by usun�� wyraz.

  UWAGA: Litera  d  pojawi si� na dole ekranu. Vim czeka na wpisanie  w .
	 Je�li zobaczysz inny znak, oznacza to, �e wpisa�e� co� �le; wci�nij
	 <ESC> i zacznij od pocz�tku.

---> Jest tu par� papier wyraz�w, kt�re kamie� nie nale�� do no�yce tego zdania.

  5. Powtarzaj kroki 3. i 4. dop�ki zdanie nie b�dzie poprawne, potem
  przejd� do Lekcji 2.2.

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		    Lekcja 2.2.: WI�CEJ POLECE� USUWAJ�CYCH


	      ** Wpisz	d$  aby usun�� tekst do ko�ca linii. **

  1. Wci�nij  <ESC>  aby si� upewni�, �e jeste� w trybie Normal.

  2. Przenie� kursor do linii poni�ej oznaczonej --->.

  3. Przenie� kursor do ko�ca poprawnego zdania (PO pierwszej  . ).

  4. Wpisz  d$  aby usun�� reszt� linii.

---> Kto� wpisa� koniec tego zdania dwukrotnie. zdania dwukrotnie.


  5. Przejd� do Lekcji 2.3., by zrozumie� co si� sta�o.





~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		     Lekcja 2.3.: O OPERATORACH I RUCHACH


  Wiele polece� zmieniaj�cych tekst jest z�o�onych z operatora i ruchu.
  Format dla polecenia usuwaj�cego z operatorem  d  jest nast�puj�cy:

	    d  ruch

  gdzie:
   d      - operator usuwania.
   ruch   - na czym polecenie b�dzie wykonywane (lista poni�ej).

  Kr�tka lista ruch�w:
    w - do pocz�tku nast�pnego wyrazu WY��CZAJ�C pierwszy znak.
    e - do ko�ca bie��cego wyrazu, W��CZAJ�C ostatni znak.
    $ - do ko�ca linii, W��CZAJ�C ostatni znak.

W ten spos�b wpisanie  de  usunie znaki od kursora do ko�ca wyrazu.

UWAGA: Wpisanie tylko ruchu w trybie Normal bez operatora przeniesie kursor
       tak, jak to okre�lono.

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		    Lekcja 2.4.: U�YCIE MNO�NIKA DLA RUCHU


   ** Wpisanie liczby przed ruchem powtarza ruch odpowiedni� ilo�� razy. **

  1. Przenie� kursor na pocz�tek linii poni�ej zaznaczonej --->.

  2. Wpisz  2w  aby przenie�� kursor o dwa wyrazy do przodu.

  3. Wpisz  3e  aby przenie�� kursor do ko�ca trzeciego wyrazu w prz�d.

  4. Wpisz  0  (zero), aby przenie�� kursor na pocz�tek linii.

  5. Powt�rz kroki 2. i 3. z innymi liczbami.


 ---> To jest zwyk�y wiersz z wyrazami, po kt�rych mo�esz si� porusza�.

  6. Przejd� do lekcji 2.5.



~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		Lekcja 2.5.: U�YCIE MNO�NIKA, BY WI�CEJ USUN��


    ** Wpisanie liczby z operatorem powtarza go odpowiedni� ilo�� razy. **

  W wy�ej wspomnianej kombinacji operatora usuwania i ruchu podaj mno�nik
  przed ruchem, by wi�cej usun��:
	d  liczba  ruch

  1. Przenie� kursor do pierwszego wyrazu KAPITALIKAMI w linii zaznaczonej --->.

  2. Wpisz  2dw  aby usun�� dwa wyrazy KAPITALIKAMI.

  3. Powtarzaj kroki 1. i 2. z innymi mno�nikami, aby usun�� kolejne wyrazy
     KAPITALIKAMI jednym poleceniem

---> ta ASD WE linia QWE ASDF ZXCV FG wyraz�w zosta�a ERT FGH CF oczyszczona.

UWAGA:  Mno�nik pomi�dzy operatorem  d  i ruchem dzia�a podobnie do ruchu bez
        operatora.


~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		      Lekcja 2.6.: OPEROWANIE NA LINIACH


		   ** Wpisz  dd  aby usun�� ca�� lini�. **

  Z powodu cz�sto�ci usuwania ca�ych linii, projektanci Vi zdecydowali, �e
  b�dzie �atwiej wpisa� dwa razy  d  aby usun�� lini�.

  1. Przenie� kursor do drugiego zdania z wierszyka poni�ej.
  2. Wpisz  dd  aby usun�� wiersz.
  3. Teraz przenie� si� do czwartego wiersza.
  4. Wpisz  2dd  aby usun�� dwa wiersze.

--->  1)  R�e s� czerwone,
--->  2)  B�oto jest fajne,
--->  3)  Fio�ki s� niebieskie,
--->  4)  Mam samoch�d,
--->  5)  Zegar podaje czas,
--->  6)  Cukier jest s�odki,
--->  7)  I ty te�.


~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		      Lekcja 2.7.: POLECENIE UNDO (cofnij)


	  ** Wci�nij  u  aby cofn�� skutki ostatniego polecenia.
		 U za�, by cofn�� skutki dla ca�ej linii. **

  1. Przenie� kursor do zdania poni�ej oznaczonego ---> i umie�� go na
     pierwszym b��dzie.
  2. Wpisz  x  aby usun�� pierwszy niechciany znak.
  3. Teraz wci�nij  u  aby cofn�� skutki ostatniego polecenia.
  4. Tym razem popraw wszystkie b��dy w linii u�ywaj�c polecenia  x .
  5. Teraz wci�nij wielkie  U  aby przywr�ci� lini� do oryginalnego stanu.
  6. Teraz wci�nij  u  kilka razy, by cofn��  U  i poprzednie polecenia.
  7. Teraz wpisz CTRL-R (trzymaj r�wnocze�nie wci�ni�te klawisze CTRL i R)
     kilka razy, by cofn�� cofni�cia.

---> Poopraw b��dyyy w teej liniii i zaamiie� je prrzez coofnij.

  8. To s� bardzo po�yteczne polecenia.

     Przejd� teraz do podsumowania Lekcji 2.

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
			     LEKCJA 2. PODSUMOWANIE


  1. By usun�� znaki od kursora do nast�pnego wyrazu, wpisz:   dw
  2. By usun�� znaki od kursora do ko�ca linii, wpisz:    d$
  3. By usun�� ca�� lini�:    dd
  4. By powt�rzy� ruch, poprzed� go liczb�:    2w
  5. Format polecenia zmiany to:
                operator  [liczba]  ruch
  gdzie:
   operator  - to, co trzeba zrobi� (np.  d  dla usuwania)
   [liczba]  - opcjonalne, ile razy powt�rzy� ruch
   ruch      - przenosi nad tekstem do operowania, takim jak  w (wyraz),
	       $  (do ko�ca linii) etc.

  6. By przej�� do pocz�tku linii, u�yj zera:  0
  7. By cofn�� poprzednie polecenie, wpisz:	  u  (ma�e u)
     By cofn�� wszystkie zmiany w linii, wpisz:	  U  (wielkie U)
     By cofn�� cofni�cie, wpisz:			  CTRL-R



~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
			 Lekcja 3.1.: POLECENIE PUT (wstaw)


	  ** Wpisz  p  by wstawi� ostatnie usuni�cia za kursorem. **

  1. Przenie� kursor do pierwszej linii ---> poni�ej.

  2. Wpisz  dd  aby usun�� lini� i przechowa� j� w rejestrze Vima.

  3. Przenie� kursor do linii c), POWY�EJ tej, gdzie usuni�ta linia powinna
     si� znajdowa�.

  4. Wci�nij  p  by wstawi� lini� poni�ej kursora.

  5. Powtarzaj kroki 2. do 4. a� znajd� si� w odpowiednim porz�dku.

---> d) Jak dwa anio�ki.
---> b) Na dole fio�ki,
---> c) A my si� kochamy,
---> a) Na g�rze r�e,


~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		    Lekcja 3.2.: POLECENIE REPLACE (zast�p)


	   ** Wpisz  rx  aby zast�pi� znak pod kursorem na  x . **

  1. Przenie� kursor do pierwszej linii poni�ej oznaczonej --->

  2. Ustaw kursor na pierwszym b��dzie.

  3. Wpisz  r  a potem znak jaki powinien go zast�pi�.

  4. Powtarzaj kroki 2. i 3. dop�ki pierwsza linia nie b�dzie taka, jak druga.

--->  Kjedy ten wiersz bi� wst�kiwany, kto� wcizn�� per� z�ych klawirzy!
--->  Kiedy ten wiersz by� wstukiwany, kto� wcisn�� par� z�ych klawiszy!

  5. Teraz czas na Lekcj� 3.3.


UWAGA: Pami�taj, by uczy� si� �wicz�c, a nie pami�ciowo.


~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		     Lekcja 3.3.: OPERATOR CHANGE (zmie�)

		 ** By zmieni� do ko�ca wyrazu, wpisz  ce . **

  1. Przenie� kursor do pierwszej linii poni�ej oznaczonej --->.

  2. Umie�� kursor na  u  w lunos.

  3. Wpisz  ce  i popraw wyraz (w tym wypadku wstaw  inia ).

  4. Wci�nij <ESC> i przejd� do nast�pnej planowanej zmiany.

  5. Powtarzaj kroki 3. i 4. dop�ki pierwsze zdanie nie b�dzie takie same,
     jak drugie.

---> Ta lunos ma pire s��w, kt�re t�ina zbnic u�ifajonc pcmazu zmie�.
---> Ta linia ma par� s��w, kt�re trzeba zmieni� u�ywaj�c polecenia zmie�.

  Zauwa�, �e  ce  nie tylko zamienia wyraz, ale tak�e zmienia tryb na
  Insert (wprowadzanie).


~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		      Lekcja 3.4.: WI�CEJ ZMIAN U�YWAJ�C c


	** Polecenie change u�ywa takich samych ruch�w, jak delete. **

  1. Operator change dzia�a tak samo, jak delete. Format wygl�da tak:

	    c   [liczba]   ruch

  2. Ruchy s� tak�e takie same, np.:  w  (wyraz),  $  (koniec linii) etc.

  3. Przenie� si� do pierwszej linii poni�ej oznaczonej --->

  4. Ustaw kursor na pierwszym b��dzie.

  5. Wpisz  c$ , popraw koniec wiersza i wci�nij <ESC>.

---> Koniec tego wiersza musi by� poprawiony, aby wygl�da� tak, jak drugi.
---> Koniec tego wiersza musi by� poprawiony u�ywaj�c polecenia  c$ .

UWAGA:  Mo�esz u�ywa� <BS> aby poprawia� b��dy w czasie pisania.

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
			     LEKCJA 3. PODSUMOWANIE


  1. Aby wstawi� tekst, kt�ry zosta� wcze�niej usuni�ty wci�nij  p . To
     polecenie wstawia skasowany tekst PO kursorze (je�li ca�a linia
     zosta�a usuni�ta, zostanie ona umieszczona w linii poni�ej kursora).

  2. By zamieni� znak pod kursorem, wci�nij  r  a potem znak, kt�ry ma zast�pi�
     oryginalny.

  3. Operator change pozwala Ci na zast�pienie od kursora do miejsca, gdzie
     zabra�by Ci� ruch. Np. wpisz  ce  aby zamieni� tekst od kursora do ko�ca
     wyrazu,  c$  aby zmieni� tekst do ko�ca linii.

  4. Format do polecenia change (zmie�):

	c   [liczba]   obiekt

     Teraz przejd� do nast�pnej lekcji.



~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	       Lekcja 4.1.: PO�O�ENIE KURSORA ORAZ STATUS PLIKU

       ** Naci�nij CTRL-G aby zobaczy� swoje po�o�enie w pliku i status
	  pliku. Naci�nij  G  aby przej�� do linii w pliku. **

  UWAGA: Przeczytaj ca�� lekcj� zanim wykonasz jakie� polecenia!!!

  1. Przytrzymaj klawisz CTRL i wci�nij  g . U�ywamy notacji CTRL-G.
     Na dole strony pojawi si� pasek statusu z nazw� pliku i pozycj� w pliku.
     Zapami�taj numer linii dla potrzeb kroku 3.

UWAGA: Mo�esz te� zobaczy� pozycj� kursora w prawym, dolnym rogu ekranu.
       Dzieje si� tak kiedy ustawiona jest opcja 'ruler' (wi�cej w lekcji 6.).

  2. Wci�nij G aby przej�� na koniec pliku.
     Wci�nij  gg  aby przej�� do pocz�tku pliku.

  3. Wpisz numer linii, w kt�rej by�e� a potem  G . To przeniesie Ci�
     z powrotem do linii, w kt�rej by�e� kiedy wcisn��e� CTRL-G.

  4. Je�li czujesz si� wystarczaj�co pewnie, wykonaj kroki 1-3.

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
			 Lekcja 4.2.: POLECENIE SZUKAJ


	     ** Wpisz  /  a nast�pnie wyra�enie, aby je znale��. **

  1. W trybie Normal wpisz  / . Zauwa�, �e znak ten oraz kursor pojawi�
     si� na dole ekranu tak samo, jak polecenie  : .

  2. Teraz wpisz  b�ond<ENTER> .  To jest s�owo, kt�rego chcesz szuka�.

  3. By szuka� tej samej frazy ponownie, po prostu wci�nij  n .
     Aby szuka� tej frazy w przeciwnym, kierunku wci�nij  N .

  4. Je�li chcesz szuka� frazy do ty�u, u�yj polecenia  ?  zamiast  / .

  5. Aby wr�ci� gdzie by�e�, wci�nij  CTRL-O. Powtarzaj, by wr�ci� dalej. CTRL-I
     idzie do przodu.

Uwaga:  'b�ond' to nie jest metoda, by przeliterowa� b��d; 'b�ond' to b��d.
Uwaga:  Kiedy szukanie osi�gnie koniec pliku, b�dzie kontynuowane od pocz�tku
        o ile opcja 'wrapscan' nie zosta�a przestawiona.

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		Lekcja 4.3.: W POSZUKIWANIU PARUJ�CYCH NAWIAS�W


	       ** Wpisz  %  by znale�� paruj�cy ), ], lub } . **

  1. Umie�� kursor na kt�rym� z (, [, lub { w linii poni�ej oznaczonej --->.

  2. Teraz wpisz znak  % .

  3. Kursor powinien si� znale�� na paruj�cym nawiasie.

  4. Wci�nij  %  aby przenie�� kursor z powrotem do paruj�cego nawiasu.

  5. Przenie� kursor do innego (,),[,],{ lub } i zobacz co robi  % .

---> To ( jest linia testowa z (, [, ] i {, } . ))

Uwaga: Ta funkcja jest bardzo u�yteczna w debuggowaniu programu
       z niesparowanymi nawiasami!



~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		  Lekcja 4.4.: POLECENIE SUBSTITUTE (zamiana)


	 ** Wpisz  :s/stary/nowy/g  aby zamieni� 'stary' na 'nowy'. **

  1. Przenie� kursor do linii poni�ej oznaczonej --->.

  2. Wpisz  :s/czaas/czas<ENTER> .  Zauwa�, �e to polecenie zmienia
     tylko pierwsze wyst�pienie 'czaas' w linii.

  3. Teraz wpisz  :s/czaas/czas/g  . Dodane  g  oznacza zamian� (substytucj�)
     globalnie w ca�ej linii.  Zmienia wszystkie wyst�pienia 'czaas' w linii.

---> Najlepszy czaas na zobaczenie naj�adniejszych kwiat�w to czaas wiosny.

  4. Aby zmieni� wszystkie wyst�pienia �a�cucha znak�w pomi�dzy dwoma liniami,
     wpisz: :#,#s/stare/nowe/g gdzie #,# s� numerami linii ograniczaj�cych
                               region, gdzie ma nast�pi� zamiana.
     wpisz  :%s/stare/nowe/g   by zmieni� wszystkie wyst�pienia w ca�ym pliku.
     wpisz  :%s/stare/nowe/gc  by zmieni� wszystkie wyst�pienia w ca�ym
                               pliku, prosz�c o potwierdzenie za ka�dym razem.

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
			     LEKCJA 4. PODSUMOWANIE

  1. CTRL-G   poka�e Twoj� pozycj� w pliku i status pliku.  SHIFT-G przenosi
	      Ci� do ko�ca pliku.
     G        przenosi do ko�ca pliku.
     liczba G przenosi do linii [liczba].
     gg       przenosi do pierwszej linii.

  2. Wpisanie  /  a nast�pnie �a�cucha znak�w szuka �a�cucha DO PRZODU.
     Wpisanie  ?  a nast�pnie �a�cucha znak�w szuka �a�cucha DO TY�U.
     Po wyszukiwaniu wci�nij  n  by znale�� nast�pne wyst�pienie szukanej
     frazy w tym samym kierunku lub  N  by szuka� w kierunku przeciwnym.
     CTRL-O przenosi do starszych pozycji, CTRL-I do nowszych.

  3. Wpisanie  %  gdy kursor znajduje si� na (,),[,],{, lub } lokalizuje
     paruj�cy znak.

  4. By zamieni� pierwszy stary na nowy w linii, wpisz      :s/stary/nowy
     By zamieni� wszystkie stary na nowy w linii, wpisz     :s/stary/nowy/g
     By zamieni� frazy pomi�dzy dwoma liniami # wpisz      :#,#s/stary/nowy/g
     By zamieni� wszystkie wyst�pienia w pliku, wpisz       :%s/stary/nowy/g
     By Vim prosi� Ci� o potwierdzenie, dodaj 'c'	   :%s/stary/nowy/gc
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		 Lekcja 5.1.: JAK WYKONA� POLECENIA ZEWN�TRZNE?


	** Wpisz  :!  a nast�pnie zewn�trzne polecenie, by je wykona�. **

  1. Wpisz znajome polecenie  :  by ustawi� kursor na dole ekranu. To pozwala
     na wprowadzenie komendy linii polece�.

  2. Teraz wstaw  !  (wykrzyknik). To umo�liwi Ci wykonanie dowolnego
     zewn�trznego polecenia pow�oki.

  3. Jako przyk�ad wpisz  ls  za  !  a nast�pnie wci�nij <ENTER>. To polecenie
     poka�e spis plik�w w Twoim katalogu, tak jakby� by� przy znaku zach�ty
     pow�oki. Mo�esz te� u�y�  :!dir  je�li  ls  nie dzia�a.

Uwaga:  W ten spos�b mo�na wykona� wszystkie polecenia pow�oki.
Uwaga:  Wszystkie polecenia  :  musz� by� zako�czone <ENTER>.
        Od tego momentu nie zawsze b�dziemy o tym wspomina�.




~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		    Lekcja 5.2.: WI�CEJ O ZAPISYWANIU PLIK�W


	   ** By zachowa� zmiany w tek�cie, wpisz :w NAZWA_PLIKU . **

  1. Wpisz  :!dir  lub  :!ls  by zobaczy� spis plik�w w katalogu.
     Ju� wiesz, �e musisz po tym wcisn�� <ENTER>.

  2. Wybierz nazw� pliku, jaka jeszcze nie istnieje, np. TEST.

  3. Teraz wpisz:   :w TEST   (gdzie TEST jest nazw� pliku jak� wybra�e�.)

  4. To polecenie zapami�ta ca�y plik (Vim Tutor) pod nazw� TEST.
     By to sprawdzi�, wpisz  :!dir  lub  :!ls  �eby znowu zobaczy� list� plik�w.

Uwaga: Zauwa�, �e gdyby� teraz wyszed� z Vima, a nast�pnie wszed� ponownie
       poleceniem  vim TEST , plik by�by dok�adn� kopi� tutoriala, kiedy go
       zapisywa�e�.

  5. Teraz usu� plik wpisuj�c (MS-DOS):		   :!del TEST
                          lub (Unix):              :!rm TEST

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		    Lekcja 5.3.: WYBRANIE TEKSTU DO ZAPISU


	  ** By zachowa� cz�� pliku, wpisz  v ruch :w NAZWA_PLIKU **

  1. Przenie� kursor do tego wiersza.

  2. Wci�nij  v  i przenie� kursor do punktu 5. Zauwa�, �e tekst zosta�
     pod�wietlony.

  3. Wci�nij znak  : . Na dole ekranu pojawi si�  :'<,'> .

  4. Wpisz  w TEST , gdzie TEST to nazwa pliku, kt�ry jeszcze nie istnieje.
     Upewnij si�, �e widzisz  :'<,'>w TEST zanim wci�niesz Enter.

  5. Vim zapisze wybrane linie do pliku TEST. U�yj  :!dir  lub  :!ls , �eby to
     zobaczy�. Jeszcze go nie usuwaj! U�yjemy go w nast�pnej lekcji.

UWAGA: Wci�ni�cie  v  zaczyna tryb Wizualny. Mo�esz porusza� kursorem, by
       zmieni� rozmiary zaznaczenia. Mo�esz te� u�y� operatora, by zrobi� co�
       z tekstem. Na przyk�ad  d  usuwa tekst.

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		   Lekcja 5.4.: WSTAWIANIE I ��CZENIE PLIK�W


	    ** By wstawi� zawarto�� pliku, wpisz   :r NAZWA_PLIKU **

  1. Umie�� kursor tu� powy�ej tej linii.

UWAGA: Po wykonaniu kroku 2. zobaczysz tekst z Lekcji 5.3. Potem przejd�
       do DO�U, by zobaczy� ponownie t� lekcj�.

  2. Teraz wczytaj plik TEST u�ywaj�c polecenia  :r TEST , gdzie TEST
     jest nazw� pliku.
     Wczytany plik jest umieszczony poni�ej linii z kursorem.

  3. By sprawdzi� czy plik zosta� wczytany, cofnij kursor i zobacz, �e
     teraz s� dwie kopie Lekcji 5.3., orygina� i kopia z pliku.

UWAGA: Mo�esz te� wczyta� wyj�cie zewn�trznego polecenia. Na przyk�ad
       :r !ls  wczytuje wyj�cie polecenia ls i umieszcza je pod poni�ej
       kursora.


~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
			     LEKCJA 5. PODSUMOWANIE


  1.  :!polecenie wykonuje polecenie zewn�trzne.

      U�ytecznymi przyk�adami s�:

	  :!dir  -  pokazuje spis plik�w w katalogu.

	  :!rm NAZWA_PLIKU  -  usuwa plik NAZWA_PLIKU.

  2.  :w NAZWA_PLIKU  zapisuje obecny plik Vima na dysk z nazw� NAZWA_PLIKU.

  3.  v ruch :w NAZWA_PLIKU  zapisuje Wizualnie wybrane linie do NAZWA_PLIKU.

  4.  :r NAZWA_PLIKU  wczytuje z dysku plik NAZWA_PLIKU i wstawia go do
      bie��cego pliku poni�ej kursora.

  5.  :r !dir  wczytuje wyj�cie polecenia dir i umieszcza je poni�ej kursora.



~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		      Lekcja 6.1.: POLECENIE OPEN (otw�rz)


      ** Wpisz  o  by otworzy� lini� poni�ej kursora i przenie�� si� do
	 trybu Insert (wprowadzanie). **

  1. Przenie� kursor do linii poni�ej oznaczonej --->.

  2. Wpisz  o  (ma�e), by otworzy� lini� PONI�EJ kursora i przenie�� si�
     do trybu Insert (wprowadzanie).

  3. Wpisz troch� tekstu i wci�nij <ESC> by wyj�� z trybu Insert (wprowadzanie).

---> Po wci�ni�ciu  o  kursor znajdzie si� w otwartej linii w trybie Insert.

  4. By otworzy� lini� POWY�EJ kursora, wci�nij wielkie  O  zamiast ma�ego
     o . Wypr�buj to na linii poni�ej.

---> Otw�rz lini� powy�ej wciskaj�c SHIFT-O gdy kursor b�dzie na tej linii.



~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		     Lekcja 6.2.: POLECENIE APPEND (dodaj)


		  ** Wpisz  a  by doda� tekst ZA kursorem. **

  1. Przenie� kursor do pocz�tku pierwszej linii poni�ej oznaczonej --->

  2. Wciskaj  e  dop�ki kursor nie b�dzie na ko�cu li .

  3. Wpisz  a  (ma�e), aby doda� tekst ZA znakiem pod kursorem.

  4. Doko�cz wyraz tak, jak w linii poni�ej. Wci�nij <ESC> aby opu�ci� tryb
     Insert.

  5. U�yj  e  by przej�� do kolejnego niedoko�czonego wyrazu i powtarzaj kroki
     3. i 4.

---> Ta li poz Ci �wi dodaw teks do ko� lin
---> Ta linia pozwoli Ci �wiczy� dodawanie tekstu do ko�ca linii.

Uwaga:  a ,  i  oraz  A  prowadz� do trybu Insert, jedyn� r�nic� jest miejsce,
       gdzie nowe znaki b�d� dodawane.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		   Lekcja 6.3.: INNA WERSJA REPLACE (zamiana)


	   ** Wpisz wielkie  R  by zamieni� wi�cej ni� jeden znak. **

  1. Przenie� kursor do pierwszej linii poni�ej oznaczonej --->. Przenie�
     kursor do pierwszego  xxx .

  2. Wci�nij  R  i wpisz numer poni�ej w drugiej linii, tak, �e zast�pi on
     xxx.

  3. Wci�nij <ESC> by opu�ci� tryb Replace. Zauwa�, �e reszta linii pozostaje
     niezmieniona.

  5. Powtarzaj kroki by wymieni� wszystkie xxx.

---> Dodanie 123 do xxx daje xxx.
---> Dodanie 123 do 456 daje 579.

UWAGA: Tryb Replace jest jak tryb Insert, ale ka�dy znak usuwa istniej�cy
       znak.

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		  Lekcja 6.4.: KOPIOWANIE I WKLEJANIE TEKSTU


       ** u�yj operatora  y  aby skopiowa� tekst i  p  aby go wklei� **

  1. Przejd� do linii oznaczonej ---> i umie�� kursor za "a)".

  2. Wejd� w tryb Wizualny  v  i przenie� kursor na pocz�tek "pierwszy".

  3. Wci�nij  y  aby kopiowa� (yankowa�) pod�wietlony tekst.

  4. Przenie� kursor do ko�ca nast�pnej linii:  j$

  5. Wci�nij  p  aby wklei� (wpakowa�) tekst.  Dodaj:  a drugi<ESC> .

  6. U�yj trybu Wizualnego, aby wybra� " element.", yankuj go  y , przejd� do
     ko�ca nast�pnej linii  j$  i upakuj tam tekst z  p .

--->  a) to jest pierwszy element.
      b)
Uwaga: mo�esz u�y�  y  jako operatora;  yw  kopiuje jeden wyraz.

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
			 Lekcja 6.5.: USTAWIANIE OPCJI


** Ustawianie opcji tak, by szukaj lub substytucja ignorowa�y wielko�� liter **

  1. Szukaj 'ignore' wpisuj�c:    /ignore<ENTER>
     Powt�rz szukanie kilka razy naciskaj�c klawisz  n .

  2. Ustaw opcj� 'ic' (Ignore case -- ignoruj wielko�� liter) poprzez
     wpisanie:		:set ic

  3. Teraz szukaj 'ignore' ponownie wciskaj�c:  n
     Zauwa�, �e Ignore i IGNORE tak�e s� teraz znalezione.

  4. Ustaw opcje 'hlsearch' i 'incsearch':    :set hls is

  5. Teraz wprowad� polecenie szukaj ponownie i zobacz co si� zdarzy:
     /ignore<ENTER>

  6. Aby wy��czy� ignorowanie wielko�ci liter:  :set noic

Uwaga: Aby usun�� pod�wietlanie dopasowa�, wpisz:   :nohlsearch
Uwaga: Aby ignorowa� wielko�� liter dla jednego wyszukiwania: /ignore\c<ENTER>
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
			     LEKCJA 6. PODSUMOWANIE


  1. Wpisanie  o  otwiera lini� PONI�EJ kursora.
     Wpisanie  O  otwiera lini� POWY�EJ kursora.

  2. Wpisanie  a  wstawia tekst ZA znakiem, na kt�rym jest kursor.
     Wpisanie  A  dodaje tekst na ko�cu linii.

  3. Polecenie  e  przenosi do ko�ca wyrazu.
  4. Operator  y  yankuje (kopiuje) tekst,  p  pakuje (wkleja) go.
  5. Wpisanie wielkiego  R  wprowadza w tryb Replace (zamiana) dop�ki
     nie zostanie wci�ni�ty <ESC>.
  6. Wpisanie ":set xxx" ustawia opcj� "xxx". Niekt�re opcje:
	'ic'  'ignorecase'	ignoruj wielko�� znak�w
	'is'  'incsearch'	poka� cz�ciowe dopasowania
	'hls' 'hlsearch'	pod�wietl wszystkie dopasowania
     Mo�esz u�y� zar�wno d�ugiej, jak i kr�tkiej formy.
  7. Dodaj "no", aby wy��czy� opcj�:   :set noic





~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
			 LEKCJA 7.1. JAK UZYSKA� POMOC?

		      ** U�ycie systemu pomocy on-line **

  Vim posiada bardzo dobry system pomocy on-line. By zacz��, spr�buj jednej
  z trzech mo�liwo�ci:
	- wci�nij klawisz <HELP> (je�li taki masz)
	- wci�nij klawisz <F1> (je�li taki masz)
	- wpisz   :help<ENTER>

  Przeczytaj tekst w oknie pomocy, aby dowiedzie� si� jak dzia�a pomoc.
  wpisz CTRL-W CTRL-W    aby przeskoczy� z jednego okna do innego
  wpisz :q<ENTER>        aby zamkn�� okno pomocy.

  Mo�esz te� znale�� pomoc na ka�dy temat podaj�c argument polecenia ":help".
  Spr�buj tych (nie zapomnij wcisn�� <ENTER>):

  :help w
  :help c_CTRL-D
  :help insert-index
  :help user-manual
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		   LEKCJA 7.2. TWORZENIE SKRYPTU STARTOWEGO

			  ** W��cz mo�liwo�ci Vima **

  Vim ma o wiele wi�cej mo�liwo�ci ni� Vi, ale wi�kszo�� z nich jest domy�lnie
  wy��czona. Je�li chcesz w��czy� te mo�liwo�ci na starcie musisz utworzy�
  plik "vimrc".

  1. Pocz�tek edycji pliku "vimrc" zale�y od Twojego systemu:
     :edit ~/.vimrc	     dla Uniksa
     :edit ~/_vimrc          dla MS-Windows
  2. Teraz wczytaj przyk�adowy plik "vimrc":
     :read $VIMRUNTIME/vimrc_example.vim
  3. Zapisz plik:
     :w

  Nast�pnym razem, gdy zaczniesz prac� w Vimie b�dzie on u�ywa� pod�wietlania
  sk�adni. Mo�esz doda� wszystkie swoje ulubione ustawienia do tego pliku
  "vimrc".
  Aby uzyska� wi�cej informacji, wpisz     :help vimrc-intro

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
			  Lekcja 7.3.: UZUPE�NIANIE


	      ** Uzupe�nianie linii polece� z CTRL-D i <TAB> **

  1. Upewnij si�, �e Vim nie jest w trybie kompatybilno�ci:   :set nocp

  2. Zerknij, jakie pliki s� w bie��cym katalogu:   :!ls   lub   :!dir

  3. Wpisz pocz�tek polecenia:   :e

  4. Wci�nij  CTRL-D  i Vim poka�e list� polece�, jakie zaczynaj� si� na "e".

  5. Wci�nij  <TAB>  i Vim uzupe�ni polecenie do ":edit".

  6. Dodaj spacj� i zacznij wpisywa� nazw� istniej�cego pliku:   :edit FIL

  7. Wci�nij <TAB>. Vim uzupe�ni nazw� (je�li jest niepowtarzalna).

UWAGA: Uzupe�nianie dzia�a dla wielu polece�. Spr�buj wcisn�� CTRL-D i <TAB>.
       U�yteczne zw�aszcza przy  :help .
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
			    Lekcja 7. PODSUMOWANIE


  1. Wpisz  :help  albo wci�nij <F1> lub <Help> aby otworzy� okno pomocy.

  2. Wpisz  :help cmd  aby uzyska� pomoc o  cmd .

  3. Wpisz  CTRL-W CTRL-W  aby przeskoczy� do innego okna.

  4. Wpisz  :q  aby zamkn�� okno pomocy.

  5. Utw�rz plik startowy vimrc aby zachowa� wybrane ustawienia.

  6. Po poleceniu  : , wci�nij CTRL-D aby zobaczy� mo�liwe uzupe�nienia.
     Wci�nij <TAB> aby u�y� jednego z nich.






~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

  Tutaj si� ko�czy tutorial Vima. Zosta� on pomy�lany tak, aby da� kr�tki
  przegl�d jego mo�liwo�ci, wystarczaj�cy by� m�g� go u�ywa�. Jest on
  daleki od kompletno�ci, poniewa� Vim ma o wiele, wiele wi�cej polece�.

  Dla dalszej nauki rekomendujemy ksi��k�:
	Vim - Vi Improved - autor Steve Oualline
	Wydawca: New Riders
  Pierwsza ksi��ka ca�kowicie po�wi�cona Vimowi. U�yteczna zw�aszcza dla
  pocz�tkuj�cych. Zawiera wiele przyk�ad�w i ilustracji.
  Zobacz https://iccf-holland.org./click5.html

  Starsza pozycja i bardziej o Vi ni� o Vimie, ale tak�e warta
  polecenia:
	Learning the Vi Editor - autor Linda Lamb
	Wydawca: O'Reilly & Associates Inc.
  To dobra ksi��ka, by dowiedzie� si� niemal wszystkiego, co chcia�by� zrobi�
  z Vi. Sz�sta edycja zawiera te� informacje o Vimie.

  Po polsku wydano:
	Edytor vi. Leksykon kieszonkowy - autor Arnold Robbins
	Wydawca: Helion 2001 (O'Reilly).
	ISBN: 83-7197-472-8
	http://helion.pl/ksiazki/vilek.htm
  Jest to ksi��eczka zawieraj�ca spis polece� vi i jego najwa�niejszych
  klon�w (mi�dzy innymi Vima).

	Edytor vi - autorzy Linda Lamb i Arnold Robbins
	Wydawca: Helion 2001 (O'Reilly) - wg 6. ang. wydania
	ISBN: 83-7197-539-2
	http://helion.pl/ksiazki/viedyt.htm
  Rozszerzona wersja Learning the Vi Editor w polskim t�umaczeniu.

  Ten tutorial zosta� napisany przez Michaela C. Pierce'a i Roberta K. Ware'a,
  Colorado School of Mines korzystaj�c z pomocy Charlesa Smitha,
  Colorado State University.
  E-mail: bware@mines.colorado.edu.

  Zmodyfikowane dla Vima przez Brama Moolenaara.

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

  Przet�umaczone przez Miko�aja Machowskiego,
  Sierpie� 2001,
  rev. Marzec 2002
  2nd rev. Wrzesie� 2004
  3rd rev. Marzec 2006
  4th rev. Grudzie� 2008
  Wszelkie uwagi prosz� kierowa� na: mikmach@wp.pl
